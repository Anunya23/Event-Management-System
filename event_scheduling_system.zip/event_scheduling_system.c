#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define MAX_NAME 100
#define MAX_DATE 20
#define MAX_TIME 10

struct Event {
    char name[MAX_NAME];
    char date[MAX_DATE];
    char time[MAX_TIME];
    int priority;
    struct Event* next;
};

struct Event* head = NULL;

struct Event* createEvent(char name[], char date[], char time[], int priority) {
    struct Event* newEvent = (struct Event*)malloc(sizeof(struct Event));
    strcpy(newEvent->name, name);
    strcpy(newEvent->date, date);
    strcpy(newEvent->time, time);
    newEvent->priority = priority;
    newEvent->next = NULL;
    return newEvent;
}

void addEvent(char name[], char date[], char time[], int priority) {
    struct Event* newEvent = createEvent(name, date, time, priority);

    if (head == NULL || priority < head->priority) {
        newEvent->next = head;
        head = newEvent;
    } else {
        struct Event* temp = head;
        while (temp->next != NULL && temp->next->priority <= priority) {
            temp = temp->next;
        }
        newEvent->next = temp->next;
        temp->next = newEvent;
    }

    printf("\nEvent added successfully!\n");
}

void displayEvents() {
    if (head == NULL) {
        printf("\nNo events to display.\n");
        return;
    }

    struct Event* temp = head;
    printf("\nAll Scheduled Events (by Priority):\n");
    while (temp != NULL) {
        printf("\nEvent Name   : %s", temp->name);
        printf("\nEvent Date   : %s", temp->date);
        printf("\nEvent Time   : %s", temp->time);
        printf("\nEvent Priority: %d\n", temp->priority);
        temp = temp->next;
    }
}

void viewNextEvent() {
    if (head == NULL) {
        printf("\nNo upcoming events.\n");
        return;
    }

    printf("\nNext Upcoming Event:\n");
    printf("Event Name   : %s\n", head->name);
    printf("Event Date   : %s\n", head->date);
    printf("Event Time   : %s\n", head->time);
    printf("Event Priority: %d\n", head->priority);
}

void deleteNextEvent() {
    if (head == NULL) {
        printf("\nNo events to delete.\n");
        return;
    }

    struct Event* temp = head;
    head = head->next;
    printf("\nDeleted Event: %s\n", temp->name);
    free(temp);
}

int main() {
    int choice, priority;
    char name[MAX_NAME], date[MAX_DATE], time[MAX_TIME];

    while (1) {
        printf("\n===== EVENT SCHEDULING SYSTEM =====");
        printf("\n1. Add Event");
        printf("\n2. View Next Event");
        printf("\n3. Display All Events");
        printf("\n4. Delete Next Event");
        printf("\n5. Exit");
        printf("\nEnter your choice: ");
        scanf("%d", &choice);
        getchar();

        switch (choice) {
            case 1:
                printf("\nEnter Event Name: ");
                fgets(name, sizeof(name), stdin);
                name[strcspn(name, "\n")] = '\0';

                printf("Enter Event Date (DD/MM/YYYY): ");
                fgets(date, sizeof(date), stdin);
                date[strcspn(date, "\n")] = '\0';

                printf("Enter Event Time (HH:MM): ");
                fgets(time, sizeof(time), stdin);
                time[strcspn(time, "\n")] = '\0';

                printf("Enter Priority (1 = High, 5 = Low): ");
                scanf("%d", &priority);
                addEvent(name, date, time, priority);
                break;

            case 2:
                viewNextEvent();
                break;

            case 3:
                displayEvents();
                break;

            case 4:
                deleteNextEvent();
                break;

            case 5:
                printf("\nExiting Event Scheduling System. Goodbye!\n");
                exit(0);

            default:
                printf("\nInvalid choice. Please try again.\n");
        }
    }

    return 0;
}
